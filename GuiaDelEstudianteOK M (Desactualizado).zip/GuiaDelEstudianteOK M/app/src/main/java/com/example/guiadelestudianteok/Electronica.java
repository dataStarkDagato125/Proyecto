package com.example.guiadelestudianteok;

public class Electronica extends Especialidad {
    public Electronica() {

        super(
                R.string.txt_Electronica,
                "Descripcionrtjh5kyni jiejnbigtuewnbgtuiw uiebguiwbeg er uigergbuibg uigwebuirgb",
                R.mipmap.escudo_ok,
                new Class[]{ TerceroElectronica.class}
        );
    }
}

// tove que tapar todo esto para probar lo de computacion