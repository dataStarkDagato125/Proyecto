package com.example.guiadelestudianteok;

public class Construcciones extends Especialidad {
    public Construcciones() {

        super(
                R.string.txt_Construcciones,
                "Descripcionrtjh5kyni jiejnbigtuewnbgtuiw uiebguiwbeg er uigergbuibg uigwebuirgb",
                R.mipmap.escudo_ok,
                new Class[]{ TerceroConstrucciones.class}
        );
    }
}


// tove que tapar todo esto para probar lo de computacion