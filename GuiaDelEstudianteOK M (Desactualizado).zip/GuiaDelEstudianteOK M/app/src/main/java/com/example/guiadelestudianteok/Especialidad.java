package com.example.guiadelestudianteok;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.Exception;


public abstract class Especialidad extends AppCompatActivity {
    protected int nombre;
    protected String descripcion;
    protected int escudo;
    protected Class[] anios;


    Especialidad(int nombre, String descripcion, int escudo, Class[] anios){
        if(anios.length == 1) // esto en realidad deverian se 4, pero lo deje en 1 para hacer las pruebas
            this.anios = anios;
        else
            throw new Error("deben ser 4 años en C.S.");

        this.nombre = nombre;
        this.descripcion = descripcion;
        this.escudo = escudo;

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_especialidad);

        TextView tvNombre = (TextView)findViewById(R.id.txv_NombreEsp);
        tvNombre.setText(getString(nombre));
        ImageView imgEscudo = (ImageView)findViewById(R.id.img_Escudo);
        imgEscudo.setImageResource(escudo);
        TextView tvDescripcion = (TextView)findViewById(R.id.txv_Descripcion);
        tvDescripcion.setText(descripcion);
    }

    public void IrATercero(View view){
        Intent i = new Intent(this, anios[0]);
        startActivity(i);
    }

    public void IrATerceroConstrucciones(View view){
        Intent l = new Intent(this, anios[0]);
        startActivity(l);
    }

    public  void IrATerceroElectrica(View view){
        Intent n =new Intent(this, anios[0]);
        startActivity(n);
    }

    public void IrATerceroElectronica(View view){
        Intent e = new Intent(this,anios[0]);
        startActivity(e);
    }

    public void IrATerceroMecanica(View view){
        Intent m = new Intent(this, anios[0]);
        startActivity(m);
    }

    public void IrATerceroQuimica(View view){
        Intent q = new Intent(this, anios[0]);
        startActivity(q);
    }

    public void IrACuarto(View view){
        Intent a = new Intent(this, anios[0]);
        startActivity(a);
    }

    public void IrACuartoConstrucciones(View view){
        Intent a = new Intent(this, anios[0]);
        startActivity(a);
    }

    public void IrACuartoElectrica(View view){
        Intent a = new Intent(this, anios[0]);
        startActivity(a);
    }

    public void IrACuartoElectronica(View view){
        Intent a = new Intent(this, anios[0]);
        startActivity(a);
    }
    public void IrACuartoMecanica(View view){
        Intent a = new Intent(this, anios[0]);
        startActivity(a);
    }

    public void IrACuartoQuimica(View view){
        Intent a = new Intent(this, anios[0]);
        startActivity(a);
    }

    public void IrAQuintoQuimica(View view){
        Intent b = new Intent(this, anios[0]);
        startActivity(b);
    }

    public void IrAQuintoMecanica(View view){
        Intent b = new Intent(this, anios[0]);
        startActivity(b);
    }

    public void IrAQuintoElectronica(View view){
        Intent b = new Intent(this, anios[0]);
        startActivity(b);
    }

    public void IrAQuintoElectrica(View view){
        Intent b = new Intent(this, anios[0]);
        startActivity(b);
    }
    public void IrAQuintoConstrucciones(View view){
        Intent b = new Intent(this, anios[0]);
        startActivity(b);
    }

    public void IrAQuintoComputacion(View view){
        Intent b = new Intent(this, anios[0]);
        startActivity(b);
    }

    public void IrASextoQuimica(View view){
        Intent c = new Intent(this, anios[0]);
        startActivity(c);
    }

    public void IrASextoMecanica(View view){
        Intent c = new Intent(this, anios[0]);
        startActivity(c);
    }

    public void IrASextoElectronica(View view){
        Intent c = new Intent(this, anios[0]);
        startActivity(c);
    }

    public void IrASextoElectrica(View view){
        Intent c = new Intent(this, anios[0]);
        startActivity(c);
    }

    public void IrASextoConstrucciones(View view){
        Intent c = new Intent(this, anios[0]);
        startActivity(c);
    }

    public void IrASextoComputacion(View view){
        Intent c = new Intent(this, anios[0]);
        startActivity(c);
    }
}
