package com.example.guiadelestudianteok;

public class Computacion extends Especialidad {
    public Computacion() {
        super(
                R.string.txt_Computacion,
                "Descripcionrtjh5kyni jiejnbigtuewnbgtuiw uiebguiwbeg er uigergbuibg uigwebuirgb",
                R.mipmap.escudo_ok,
                new Class[]{ TerceroComputacion.class }
        );
    }
}