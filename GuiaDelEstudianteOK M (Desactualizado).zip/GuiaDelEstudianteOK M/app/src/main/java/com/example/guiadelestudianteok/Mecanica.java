package com.example.guiadelestudianteok;

public class Mecanica extends Especialidad {
    public Mecanica() {

        super(
                R.string.txt_Mecanica,
                "Descripcionrtjh5kyni jiejnbigtuewnbgtuiw uiebguiwbeg er uigergbuibg uigwebuirgb",
                R.mipmap.escudo_ok,
                new Class[]{ TerceroMecanica.class}
        );
    }
}


// tove que tapar todo esto para probar lo de computacion