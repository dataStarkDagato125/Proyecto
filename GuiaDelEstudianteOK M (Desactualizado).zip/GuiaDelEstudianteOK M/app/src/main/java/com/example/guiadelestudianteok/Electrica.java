package com.example.guiadelestudianteok;

public class Electrica extends Especialidad{
    public Electrica() {
        super(
            R.string.txt_Electrica,
            "Descripcionrtjh5kyni jiejnbigtuewnbgtuiw uiebguiwbeg er uigergbuibg uigwebuirgb",
            R.mipmap.escudo_ok,
                new Class[]{ TerceroElectrica.class}
        );
    }
}

// tove que tapar todo esto para probar lo de computacion