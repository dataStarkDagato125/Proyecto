package com.example.guiadelestudianteok;

public class Quimica extends Especialidad {
    public Quimica() {
        super(
                R.string.txt_Quimica,
                "Descripcionrtjh5kyni jiejnbigtuewnbgtuiw uiebguiwbeg er uigergbuibg uigwebuirgb",
                R.mipmap.escudo_ok,
                new Class[]{TerceroQuimica.class}
        );
    }
}

// tove que tapar todo esto para probar lo de computacion